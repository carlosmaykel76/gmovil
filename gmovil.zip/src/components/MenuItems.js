
const MenuItems = [
    {
        menuTitle: "Home",
        pageURL: "/"
    },
    {
        menuTitle: "Nuevo Movil", 
        pageURL:"/new"
    },
    {
        menuTitle: "About", 
        pageURL:"/about"
    }
];

export default MenuItems